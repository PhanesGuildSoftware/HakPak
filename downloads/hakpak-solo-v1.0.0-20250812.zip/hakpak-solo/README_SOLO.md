# HakPak Solo Edition

Thank you for purchasing HakPak Solo!

## What You've Received

This package contains:
- HakPak core installation files
- License activation system
- Complete documentation
- Your activation key (sent via email)

## Quick Start

1. Extract this package to your preferred directory
2. Make the installer executable: `chmod +x install.sh`
3. Run the installer: `./install.sh`
4. Activate your license: `./hakpak.sh --activate "YOUR_ACTIVATION_KEY"`

## Your License Tier: Solo

### Solo Ops Features:
- ✅ Core tool installation (15+ security tools)
- ✅ Automatic repository management
- ✅ Basic update system
- ✅ Community support via GitHub
- ✅ Standard installation profiles

### Usage:
```bash
./hakpak.sh --install nmap
./hakpak.sh --install-category network
./hakpak.sh --list-tools
```

### Support:
- GitHub Issues: https://github.com/PhanesGuildSoftware/hakpak/issues
- Documentation: https://github.com/PhanesGuildSoftware/hakpak

## Need Help?

1. Check the main README.md for detailed documentation
2. Review SECURITY.md for security considerations
3. See CHANGELOG.md for version history
4. Contact support using the methods above

## License

By using HakPak, you agree to the End-User License Agreement (EULA.md).

---
© 2025 PhanesGuild Software LLC. All rights reserved.
