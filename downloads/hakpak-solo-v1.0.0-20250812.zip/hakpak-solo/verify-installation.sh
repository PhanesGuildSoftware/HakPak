#!/bin/bash
# HakPak solo Installation Verification

echo "Verifying HakPak solo installation..."

# Check core files
if [ ! -f "hakpak.sh" ]; then
    echo "❌ hakpak.sh not found"
    exit 1
fi

if [ ! -f "install.sh" ]; then
    echo "❌ install.sh not found"
    exit 1
fi

if [ ! -d "lib" ]; then
    echo "❌ lib directory not found"
    exit 1
fi

echo "✅ Core files present"

# Check tier configuration
if [ -f "config/tier.conf" ]; then
    source config/tier.conf
    if [ "$HAKPAK_TIER" = "solo" ]; then
        echo "✅ Tier configuration correct: solo"
    else
        echo "❌ Tier configuration mismatch"
        exit 1
    fi
else
    echo "❌ Tier configuration not found"
    exit 1
fi

echo "✅ HakPak solo package verification complete"
echo "Next step: Run ./install.sh to install HakPak"
